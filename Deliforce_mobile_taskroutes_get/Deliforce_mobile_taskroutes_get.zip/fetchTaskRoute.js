const mongoose = require('mongoose');
const result = require('./result');
const helper = require('./util');
const constant = require('./constant')();
const taskModel = require('./model').task;
const userModel = require('./model').user;
var geolib = require('geolib');
const moment = require('moment-timezone');

module.exports = {
    fetchRoutes: (event, cb, principals) => {
        fetchDriverId(principals).then((driverDetails) => {
            const driverData = driverDetails.toObject();
            // let driverLocation= {latitude:driverDetails.location.coordinates[0],longitude:driverDetails.location.coordinates[0]}
            let driverLocation = {
                latitude: driverData.location.coordinates[1],
                longitude: driverData.location.coordinates[0]
            }
            let driverId = driverData._id;
            fetchTasks(driverId).then((taskDetails) => {
                // var fetchedTasks = taskDetails.toObject();
                changeTaskOrder(driverLocation, taskDetails, cb);
            });

        });
    }
};

//change the task order based on the
function changeTaskOrder(driverLocation, taskArry, cb) {
    console.log('coming here');

    let finalArry = [];
    console.log(taskArry);
    if (taskArry.length) {
        let latlanArry = [];
        latlanArry = taskArry.map((t) => {
            // t = t.toObject();
            return {longitude: t.address.geometry.location.lng, latitude: t.address.geometry.location.lat}
        });
        let orderArry = geolib.orderByDistance(driverLocation, latlanArry);
        for (let i = 0; i < orderArry.length; i++) {
            finalArry.push(taskArry[Number(orderArry[i].key)]);
        }
        result.sendSuccess(cb, {'taskList': finalArry});

    } else {
        result.sendSuccess(cb, {'taskList': finalArry});
    }
}

function fetchTasks(driverId) {
    //returning fetched tasks of that day for particular driver.

    var adminDetails = {};
    adminDetails.timezone = "Asia/Calcutta"
    // var s1 = moment.tz(new Date(), 'YYYY-MM-DD', adminDetails.timezone)
    // // var e1 = moment.tz(data.filter.dateRange[1], 'YYYY-MM-DD', adminDetails.timezone)
    // //

    //    console.log(s1 + 's1');
    // //   console.log(e1 + 'e1');
    //    console.log('tzzzzzzzz', adminDetails.timezone);
    //
    //    var startDate = s1.clone().startOf('day').utc();
    //    var dateMidnight = s1.clone().endOf('day').utc();
    //
    //    let date = {
    //        $gte: new Date(startDate),
    //        $lte: new Date(dateMidnight)
    //    };
    var day = new Date();
    const startDate = day.setHours(0, 0, 0, 0);
    const dateMidnight = day.setHours(23, 59, 59, 999);
    let date = {
        $gt: new Date(startDate),
        $lt: new Date(dateMidnight)
    };
    return taskModel.find({
        driver: mongoose.Types.ObjectId(driverId),
        date: date,
        taskStatus: {$in: [2, 3, 4, 10]}
    }, {settings: 0, driverImages: 0}).then((taskList) => {
        return newTaskList = taskList.map(function (taskData) {
            console.log('each task', JSON.stringify(taskList));
            let t = taskData.toObject();
            let stDate = new Date(t.date);
            let tz = (adminDetails.timezone) ? adminDetails.timezone : 'Asia/Calcutta';
            console.log('timezone', stDate);
            let m = moment.utc(stDate, "YYYY-MM-DD h:mm:ss A");
            t.date = m.tz(tz).format("YYYY-MM-DD h:mm:ss A");
            if (t.businessType === 2 || t.businessType === 3) {
                let endDate = t.endDate;
                let m1 = moment.utc(endDate, "YYYY-MM-DD h:mm:ss A");
                t.endDate = m1.tz(tz).format("YYYY-MM-DD h:mm:ss A");
            }
            return t;
        });
    })

}

function fetchDriverId(driverSub) {
    return userModel.findOne({cognitoSub: driverSub});
}

//,taskStatus:{$in:[2,4,6,10]}