
let cb;
const result = require('./result');

// const event = {
//     "resource": "/task/taskroutes",
//     "path": "/task/taskroutes",
//     "httpMethod": "GET",
//     "headers": {
//         "Accept": "application/json",
//         "Accept-Encoding": "gzip",
//         "Authorization": "eyJraWQiOiJpNjFZbWNnWnNkK1l2UHQ3eHI5eTF0Q3RlcThua0c5XC9oWmhTZldzWm5oZz0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI0MTFlYzdjYS1iNmY5LTRlMjAtOTc2MS05NjZjZTdlNTBhZjUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbVwvYXAtc291dGgtMV96Tk1lVUdnMG8iLCJwaG9uZV9udW1iZXJfdmVyaWZpZWQiOnRydWUsImNvZ25pdG86dXNlcm5hbWUiOiI0MTFlYzdjYS1iNmY5LTRlMjAtOTc2MS05NjZjZTdlNTBhZjUiLCJhdWQiOiI1bm1maXZsM3Q5Yzd1ZDg1NXFpZDdtZjU3aiIsImV2ZW50X2lkIjoiNzgzMGM3ZWUtM2ZkNC0xMWU5LTgxZTMtNmYwMDFmZGVjOThiIiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE1NTE4NTE3MzksIm5hbWUiOiJkcml2ZXIyIiwicGhvbmVfbnVtYmVyIjoiKzkxMTIzMTIiLCJleHAiOjE1NTE5NTU1NjIsImlhdCI6MTU1MTk1MTk2MiwiZW1haWwiOiJhc2RAYXNhZGEuY29tIn0.PLioy_7-5g2ZeCXuLF0-OOmmfiOzDhUR5q-9wXfwvsrBEsqdmB6xZP2Hau9AGiQ4ZcN4_Pu8sn_O4Kth9LpBm5IDQW_3ELW7zYn1qGhTobxvbgf8fQKgD88Po6avf2xf1YJVnE-lXWif3B6wXe4QoCJqQ6775eujpiatKciex9jDqRWH98dKC4MkBzGAQe3B8nlIIn9A4TZhb2nVXYeiqe2BUirmLsJEtjKwWl01NWSpiy0Tc3f77-Qsl-GnveXw2w-GQrBJ5svqqe8GOPMfldsffJVJ8v42-O45f0BuTHO3VLrKriyU_TSPPc-T-AdkkUyBiVYupMlcm1fvQHSXGw",
//         "CloudFront-Forwarded-Proto": "https",
//         "CloudFront-Is-Desktop-Viewer": "true",
//         "CloudFront-Is-Mobile-Viewer": "false",
//         "CloudFront-Is-SmartTV-Viewer": "false",
//         "CloudFront-Is-Tablet-Viewer": "false",
//         "CloudFront-Viewer-Country": "IN",
//         "content-type": "application/json",
//         "Host": "2ocwnhz66m.execute-api.ap-south-1.amazonaws.com",
//         "User-Agent": "okhttp/3.9.0",
//         "Via": "2.0 60276c945ec58972cc6306cf00aab714.cloudfront.net (CloudFront)",
//         "X-Amz-Cf-Id": "WeBgb71f_YdfceXdx3gF_uLQkFCinhHVZAJBVe6sc_TJZLxIzHkQmQ==",
//         "X-Amzn-Trace-Id": "Root=1-5c80e991-54e71a58c36a6ed061025e90",
//         "X-Forwarded-For": "106.51.73.130, 52.46.49.75",
//         "X-Forwarded-Port": "443",
//         "X-Forwarded-Proto": "https"
//     },
//     "multiValueHeaders": {
//         "Accept": [
//             "application/json"
//         ],
//         "Accept-Encoding": [
//             "gzip"
//         ],
//         "Authorization": [
//             "eyJraWQiOiJpNjFZbWNnWnNkK1l2UHQ3eHI5eTF0Q3RlcThua0c5XC9oWmhTZldzWm5oZz0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI0MTFlYzdjYS1iNmY5LTRlMjAtOTc2MS05NjZjZTdlNTBhZjUiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbVwvYXAtc291dGgtMV96Tk1lVUdnMG8iLCJwaG9uZV9udW1iZXJfdmVyaWZpZWQiOnRydWUsImNvZ25pdG86dXNlcm5hbWUiOiI0MTFlYzdjYS1iNmY5LTRlMjAtOTc2MS05NjZjZTdlNTBhZjUiLCJhdWQiOiI1bm1maXZsM3Q5Yzd1ZDg1NXFpZDdtZjU3aiIsImV2ZW50X2lkIjoiNzgzMGM3ZWUtM2ZkNC0xMWU5LTgxZTMtNmYwMDFmZGVjOThiIiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE1NTE4NTE3MzksIm5hbWUiOiJkcml2ZXIyIiwicGhvbmVfbnVtYmVyIjoiKzkxMTIzMTIiLCJleHAiOjE1NTE5NTU1NjIsImlhdCI6MTU1MTk1MTk2MiwiZW1haWwiOiJhc2RAYXNhZGEuY29tIn0.PLioy_7-5g2ZeCXuLF0-OOmmfiOzDhUR5q-9wXfwvsrBEsqdmB6xZP2Hau9AGiQ4ZcN4_Pu8sn_O4Kth9LpBm5IDQW_3ELW7zYn1qGhTobxvbgf8fQKgD88Po6avf2xf1YJVnE-lXWif3B6wXe4QoCJqQ6775eujpiatKciex9jDqRWH98dKC4MkBzGAQe3B8nlIIn9A4TZhb2nVXYeiqe2BUirmLsJEtjKwWl01NWSpiy0Tc3f77-Qsl-GnveXw2w-GQrBJ5svqqe8GOPMfldsffJVJ8v42-O45f0BuTHO3VLrKriyU_TSPPc-T-AdkkUyBiVYupMlcm1fvQHSXGw"
//         ],
//         "CloudFront-Forwarded-Proto": [
//             "https"
//         ],
//         "CloudFront-Is-Desktop-Viewer": [
//             "true"
//         ],
//         "CloudFront-Is-Mobile-Viewer": [
//             "false"
//         ],
//         "CloudFront-Is-SmartTV-Viewer": [
//             "false"
//         ],
//         "CloudFront-Is-Tablet-Viewer": [
//             "false"
//         ],
//         "CloudFront-Viewer-Country": [
//             "IN"
//         ],
//         "content-type": [
//             "application/json"
//         ],
//         "Host": [
//             "2ocwnhz66m.execute-api.ap-south-1.amazonaws.com"
//         ],
//         "User-Agent": [
//             "okhttp/3.9.0"
//         ],
//         "Via": [
//             "2.0 60276c945ec58972cc6306cf00aab714.cloudfront.net (CloudFront)"
//         ],
//         "X-Amz-Cf-Id": [
//             "WeBgb71f_YdfceXdx3gF_uLQkFCinhHVZAJBVe6sc_TJZLxIzHkQmQ=="
//         ],
//         "X-Amzn-Trace-Id": [
//             "Root=1-5c80e991-54e71a58c36a6ed061025e90"
//         ],
//         "X-Forwarded-For": [
//             "106.51.73.130, 52.46.49.75"
//         ],
//         "X-Forwarded-Port": [
//             "443"
//         ],
//         "X-Forwarded-Proto": [
//             "https"
//         ]
//     },
//     "queryStringParameters": null,
//     "multiValueQueryStringParameters": null,
//     "pathParameters": null,
//     "stageVariables": null,
//     "requestContext": {
//         "resourceId": "4k3362",
//         "authorizer": {
//             "claims": {
//                 "sub": "411ec7ca-b6f9-4e20-9761-966ce7e50af5",
//                 "email_verified": "true",
//                 "iss": "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_zNMeUGg0o",
//                 "phone_number_verified": "true",
//                 "cognito:username": "411ec7ca-b6f9-4e20-9761-966ce7e50af5",
//                 "aud": "5nmfivl3t9c7ud855qid7mf57j",
//                 "event_id": "7830c7ee-3fd4-11e9-81e3-6f001fdec98b",
//                 "token_use": "id",
//                 "auth_time": "1551851739",
//                 "name": "driver2",
//                 "phone_number": "+9112312",
//                 "exp": "Thu Mar 07 10:46:02 UTC 2019",
//                 "iat": "Thu Mar 07 09:46:02 UTC 2019",
//                 "email": "asd@asada.com"
//             }
//         },
//         "resourcePath": "/task/taskroutes",
//         "httpMethod": "GET",
//         "extendedRequestId": "WKlusEjqBcwFuTA=",
//         "requestTime": "07/Mar/2019:09:51:13 +0000",
//         "path": "/Development/task/taskroutes",
//         "accountId": "204006638324",
//         "protocol": "HTTP/1.1",
//         "stage": "Development",
//         "domainPrefix": "2ocwnhz66m",
//         "requestTimeEpoch": 1551952273225,
//         "requestId": "8b0b5402-40be-11e9-9715-a7e67e4ae642",
//         "identity": {
//             "cognitoIdentityPoolId": null,
//             "accountId": null,
//             "cognitoIdentityId": null,
//             "caller": null,
//             "sourceIp": "106.51.73.130",
//             "accessKey": null,
//             "cognitoAuthenticationType": null,
//             "cognitoAuthenticationProvider": null,
//             "userArn": null,
//             "userAgent": "okhttp/3.9.0",
//             "user": null
//         },
//         "domainName": "2ocwnhz66m.execute-api.ap-south-1.amazonaws.com",
//         "apiId": "2ocwnhz66m"
//     },
//     "body": null,
//     "isBase64Encoded": false
// }


try {
     const getConstant = require('./constant')();




    // event.queryStringParameters = require('../../mock').data.getTasks;
    // console.log(event.queryStringParameters);
    exports.handler = (event, context, callback) => {
        console.log(JSON.stringify(event));
        cb = callback;
        context.callbackWaitsForEmptyEventLoop = false;

        getConstant.then(() => {
            //imports
            const db = require('./db').connect();
            const taskRoutes = require('./fetchTaskRoute');
            const helper = require('./util');

            if (helper.checkFromTrigger(cb, event)) return;

            /*
            principals explanation: for admin sub is clientId for manager clientId is clientId
            {  sub: 'current user cognitosub',
            role: 'role id of user',
            clientId:'exist if user is manager & this is clientid of that manager',
            teams: 'team Assigned to manager' }
            */

            const principals = event.requestContext.authorizer.claims.sub;
            // const principals="6cada284-4624-4bcc-815c-d49793e2a0c9";
            if (!principals) return;

            //connect to db
            db.then(() => taskRoutes.fetchRoutes(event, cb, principals)).catch(sendError);

            function sendError(error) {
                console.error('error +++', error);
                result.sendServerError(cb);
            }
        }).catch((err) => {
            console.log(err);
            result.sendServerError(cb);
        });
    };

} catch (err) {
    console.error('error +++', err);
    result.sendServerError(cb);
}







