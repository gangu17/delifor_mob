let cb;
const result = require('./result');
const helper = require('./util');
try {
    const getConstant = require('./constant')();
    /* const callback = function (err, data) {
       console.log('callback called+++++++++++++++++++++++++++++++++');
       console.log(err, data);
     };
       const event = {
           "data": {
               "adminArray": [
                   "d7380e5a-276b-40d0-bf91-07a09dfe98a9",
                   "ac71e6cb-8e95-442f-beda-5c3508e913cf",
                   "548675ca-0ddc-4428-a4b8-9a47474f35a9",
                   "569d50b1-1792-4531-a9ce-48fc7bdac4ee",
                   "c7fa7b3e-0a9f-49b9-944f-99b7e0ffa474"
               ],
               "batteryState": 0,
               "location_lng": 77.7500702,
               "location_lat": 12.983925,
               "status": 3,
               "driverId": "5bf41295d8d2b234b11c76a3",
               "isLogOut": false,
               "topic": "driver"
           }
       }
 */
    exports.handler = (event, context, callback) => {
        console.log('Event', JSON.stringify(event));
        const data = helper.getBodyData(event);
        cb = callback;
        context.callbackWaitsForEmptyEventLoop = false;

        getConstant.then((res) => {
            var AWS = require('aws-sdk');
            const endPointConstant = res.ENDPOINT_ARN;
            var iotdata = new AWS.IotData({endpoint: endPointConstant.ENDPOINT_ARNKEY});
            var resultData = [];
            if (data.adminArray.length > 0) {
                for (let i = 0; i < data.adminArray.length; i++) {
                    var params = {
                        topic: '/' + 'driver' + '/' + data.adminArray[i],
                        payload: JSON.stringify({
                            'driverId': data.driverId,
                            'driverStatus': data.status,
                            'location_lat': data.location_lat,
                            'location_lng': data.location_lng,
                            'currentAddress': (data.formattedAddress) ? data.formattedAddress : ''
                        }),
                        qos: 1
                    };
                    console.log(params);
                    console.log('Adminarray', data.adminArray[i]);
                    /*iotdata.publish(params, function (err, data) {
                       if (err) {
                           console.log(err);
                           result.notPublished(cb);
                       }
                       else {
                           console.log("mqtt success", JSON.stringify(data));
                           resultData.push('success');
                       }
                   });*/
                    resultData.push(iotPub(params));
                }

                Promise.all(resultData);
            }

            function iotPub(params) {
                iotdata.publish(params, function (err, data) {
                    if (err) {
                        console.log(err);
                        result.notPublished(cb);
                    }
                    else {
                        console.log("mqtt success", JSON.stringify(data));
                    }
                });
            }
        }).catch((err) => {
            console.log(err);
            result.sendServerError(cb);
        });
    };

} catch (err) {
    console.error('error +++', err);
    result.sendServerError(cb);
}







