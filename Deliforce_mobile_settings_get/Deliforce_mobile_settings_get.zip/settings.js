const result = require('./result');
const driverModel = require('./model');
const helper = require('./util');

module.exports = {
    fetchSetting:(event, cb, principals) => {
        const clientId =  principals;
        console.log('the data is consoled here toooo!!!!'+clientId);
        driverModel.findOne({cognitoSub: clientId},{settings:1},function (err, driver) {
            console.log('the data is consoled here!!!!',err, driver);
            if (err) {
                result.sendServerError(cb);
            } else {
                result.sendSuccess(cb, driver);
            }
        });
    }
};








