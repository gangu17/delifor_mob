const result = require('./result');
const driver = require('./model');
const helper = require('./util');
const mongoose = require('mongoose');

module.exports = {
  updateDriverSetting:(event,cb,principals) => {
    console.log('event', JSON.stringify(event));
    const data = helper.getBodyData(event);
    console.log(data);
    if(!data.settings){
      result.invalidInput(cb);
    } else {
        data.settings.showTraffic = false;
        console.log(data.settings);
      if (Object.keys(data.settings).length >=10) {
          const clientId = principals;
          driver.update({cognitoSub: clientId}, {$set:{settings:data.settings}}).then((resp) => {
              console.log(resp);
              result.sendSuccess(cb ,{message:'settings are updated successfully'});
          }).catch((error) => {result.sendServerError(cb)});
      } else {
        result.sendSuccess(cb,{'msg':'params is missing'})
      }
    }
  }
};








