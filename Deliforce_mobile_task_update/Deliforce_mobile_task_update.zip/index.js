let cb;
const result = require('./result');

try {
    const getConstant = require('./constant')();
    // const callback = function (err, data) {
    //     console.log('callback called+++++++++++++++++++++++++++++++++');
    //     console.log(err, data);
    // };
    //
    // const event = {
    //     "resource": "/task/taskupdate",
    //     "path": "/task/taskupdate",
    //     "httpMethod": "POST",
    //     "headers": {
    //         "Accept": "application/json",
    //         "Accept-Encoding": "gzip",
    //         "Authorization": "eyJraWQiOiJpNjFZbWNnWnNkK1l2UHQ3eHI5eTF0Q3RlcThua0c5XC9oWmhTZldzWm5oZz0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJmYTFjYTY0Mi00ZGQwLTRmOWYtYmY2MC05N2FlMjFmNjg4YjkiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbVwvYXAtc291dGgtMV96Tk1lVUdnMG8iLCJwaG9uZV9udW1iZXJfdmVyaWZpZWQiOnRydWUsImNvZ25pdG86dXNlcm5hbWUiOiJmYTFjYTY0Mi00ZGQwLTRmOWYtYmY2MC05N2FlMjFmNjg4YjkiLCJhdWQiOiI1bm1maXZsM3Q5Yzd1ZDg1NXFpZDdtZjU3aiIsImV2ZW50X2lkIjoiYWYzNzlkZGEtODI5Yi0xMWU5LWI3N2EtMmZkMWUyYzA5NzBjIiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE1NTkxOTQwNzgsIm5hbWUiOiJoZXJvIiwicGhvbmVfbnVtYmVyIjoiKzkxNzg5NjU4ODg4NyIsImV4cCI6MTU1OTE5NzY3OCwiaWF0IjoxNTU5MTk0MDc4LCJlbWFpbCI6Imhlcm9AbWFpbGluYXRvci5jb20ifQ.g66_XNNghnIjokco2fL8--06Ex0sjbY6KfpDzoGBGvT0gilAeOaqOeWwVxw0WGM3qINFdzxtseZisrwoGzDI-jBuZQViQOY2iTxmP8EGaojcfhjWu2S2JqgFHr1roygAB4ZWJ7vgqdWhSxcNdj1t2mdHeMHmF_lOvG0WtGRSy1p8tw6tqEtvX61NZsGDzXES9HR9ftBLiz4s04bolCzT-brxqlXV50nmcE9qUPKKwC1J96R6Lz1IvFzNl0_qfOGSVtNm6JwfQypYGMDoMfWkSH_CstCjBwTLPQnWDUldh4pq620bQKxXDiC4bZW22V5DdccFodzR7KmaKDTMYjy3SA",
    //         "CloudFront-Forwarded-Proto": "https",
    //         "CloudFront-Is-Desktop-Viewer": "true",
    //         "CloudFront-Is-Mobile-Viewer": "false",
    //         "CloudFront-Is-SmartTV-Viewer": "false",
    //         "CloudFront-Is-Tablet-Viewer": "false",
    //         "CloudFront-Viewer-Country": "IN",
    //         "content-type": "application/json",
    //         "devicetoken": "c2pjRMy30IU:APA91bF4ngQFWgB0G09OhwOGuHJU8YNx9vZ4lUJ1ykvkvzTxHsthvnKtZCgYg_GBW1QWoDxbI5DfPH4XsK1cjV5a9pm9Y059DNgUsEtPybDTDdjG6NCsxfd45K-9vE6v0gKxStCqLJEm",
    //         "Host": "2ocwnhz66m.execute-api.ap-south-1.amazonaws.com",
    //         "User-Agent": "okhttp/3.12.0",
    //         "Via": "2.0 db1ab646432f65c49f319f350f911da8.cloudfront.net (CloudFront)",
    //         "X-Amz-Cf-Id": "Oyd1PvQy4eV7pWtZ11yx_61e-QfUDgUM_EEm0P4BgiESl7r0Twg8iw==",
    //         "X-Amzn-Trace-Id": "Root=1-5cef69f1-081ac0ec98c50cc86a3f627c",
    //         "X-Forwarded-For": "157.45.18.1, 52.46.37.136",
    //         "X-Forwarded-Port": "443",
    //         "X-Forwarded-Proto": "https"
    //     },
    //     "multiValueHeaders": {
    //         "Accept": [
    //             "application/json"
    //         ],
    //         "Accept-Encoding": [
    //             "gzip"
    //         ],
    //         "Authorization": [
    //             "eyJraWQiOiJpNjFZbWNnWnNkK1l2UHQ3eHI5eTF0Q3RlcThua0c5XC9oWmhTZldzWm5oZz0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJmYTFjYTY0Mi00ZGQwLTRmOWYtYmY2MC05N2FlMjFmNjg4YjkiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbVwvYXAtc291dGgtMV96Tk1lVUdnMG8iLCJwaG9uZV9udW1iZXJfdmVyaWZpZWQiOnRydWUsImNvZ25pdG86dXNlcm5hbWUiOiJmYTFjYTY0Mi00ZGQwLTRmOWYtYmY2MC05N2FlMjFmNjg4YjkiLCJhdWQiOiI1bm1maXZsM3Q5Yzd1ZDg1NXFpZDdtZjU3aiIsImV2ZW50X2lkIjoiYWYzNzlkZGEtODI5Yi0xMWU5LWI3N2EtMmZkMWUyYzA5NzBjIiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE1NTkxOTQwNzgsIm5hbWUiOiJoZXJvIiwicGhvbmVfbnVtYmVyIjoiKzkxNzg5NjU4ODg4NyIsImV4cCI6MTU1OTE5NzY3OCwiaWF0IjoxNTU5MTk0MDc4LCJlbWFpbCI6Imhlcm9AbWFpbGluYXRvci5jb20ifQ.g66_XNNghnIjokco2fL8--06Ex0sjbY6KfpDzoGBGvT0gilAeOaqOeWwVxw0WGM3qINFdzxtseZisrwoGzDI-jBuZQViQOY2iTxmP8EGaojcfhjWu2S2JqgFHr1roygAB4ZWJ7vgqdWhSxcNdj1t2mdHeMHmF_lOvG0WtGRSy1p8tw6tqEtvX61NZsGDzXES9HR9ftBLiz4s04bolCzT-brxqlXV50nmcE9qUPKKwC1J96R6Lz1IvFzNl0_qfOGSVtNm6JwfQypYGMDoMfWkSH_CstCjBwTLPQnWDUldh4pq620bQKxXDiC4bZW22V5DdccFodzR7KmaKDTMYjy3SA"
    //         ],
    //         "CloudFront-Forwarded-Proto": [
    //             "https"
    //         ],
    //         "CloudFront-Is-Desktop-Viewer": [
    //             "true"
    //         ],
    //         "CloudFront-Is-Mobile-Viewer": [
    //             "false"
    //         ],
    //         "CloudFront-Is-SmartTV-Viewer": [
    //             "false"
    //         ],
    //         "CloudFront-Is-Tablet-Viewer": [
    //             "false"
    //         ],
    //         "CloudFront-Viewer-Country": [
    //             "IN"
    //         ],
    //         "content-type": [
    //             "application/json"
    //         ],
    //         "devicetoken": [
    //             "c2pjRMy30IU:APA91bF4ngQFWgB0G09OhwOGuHJU8YNx9vZ4lUJ1ykvkvzTxHsthvnKtZCgYg_GBW1QWoDxbI5DfPH4XsK1cjV5a9pm9Y059DNgUsEtPybDTDdjG6NCsxfd45K-9vE6v0gKxStCqLJEm"
    //         ],
    //         "Host": [
    //             "2ocwnhz66m.execute-api.ap-south-1.amazonaws.com"
    //         ],
    //         "User-Agent": [
    //             "okhttp/3.12.0"
    //         ],
    //         "Via": [
    //             "2.0 db1ab646432f65c49f319f350f911da8.cloudfront.net (CloudFront)"
    //         ],
    //         "X-Amz-Cf-Id": [
    //             "Oyd1PvQy4eV7pWtZ11yx_61e-QfUDgUM_EEm0P4BgiESl7r0Twg8iw=="
    //         ],
    //         "X-Amzn-Trace-Id": [
    //             "Root=1-5cef69f1-081ac0ec98c50cc86a3f627c"
    //         ],
    //         "X-Forwarded-For": [
    //             "157.45.18.1, 52.46.37.136"
    //         ],
    //         "X-Forwarded-Port": [
    //             "443"
    //         ],
    //         "X-Forwarded-Proto": [
    //             "https"
    //         ]
    //     },
    //     "queryStringParameters": null,
    //     "multiValueQueryStringParameters": null,
    //     "pathParameters": null,
    //     "stageVariables": null,
    //     "requestContext": {
    //         "resourceId": "622sgu",
    //         "authorizer": {
    //             "claims": {
    //                 "sub": "fa1ca642-4dd0-4f9f-bf60-97ae21f688b9",
    //                 "email_verified": "true",
    //                 "iss": "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_zNMeUGg0o",
    //                 "phone_number_verified": "true",
    //                 "cognito:username": "fa1ca642-4dd0-4f9f-bf60-97ae21f688b9",
    //                 "aud": "5nmfivl3t9c7ud855qid7mf57j",
    //                 "event_id": "af379dda-829b-11e9-b77a-2fd1e2c0970c",
    //                 "token_use": "id",
    //                 "auth_time": "1559194078",
    //                 "name": "hero",
    //                 "phone_number": "+917896588887",
    //                 "exp": "Thu May 30 06:27:58 UTC 2019",
    //                 "iat": "Thu May 30 05:27:58 UTC 2019",
    //                 "email": "hero@mailinator.com"
    //             }
    //         },
    //         "resourcePath": "/task/taskupdate",
    //         "httpMethod": "POST",
    //         "extendedRequestId": "ae19yGdUhcwFgDg=",
    //         "requestTime": "30/May/2019:05:28:17 +0000",
    //         "path": "/Development/task/taskupdate",
    //         "accountId": "204006638324",
    //         "protocol": "HTTP/1.1",
    //         "stage": "Development",
    //         "domainPrefix": "2ocwnhz66m",
    //         "requestTimeEpoch": 1559194097897,
    //         "requestId": "baea4df3-829b-11e9-91c3-b1de0bf89a2d",
    //         "identity": {
    //             "cognitoIdentityPoolId": null,
    //             "accountId": null,
    //             "cognitoIdentityId": null,
    //             "caller": null,
    //             "sourceIp": "157.45.18.1",
    //             "principalOrgId": null,
    //             "accessKey": null,
    //             "cognitoAuthenticationType": null,
    //             "cognitoAuthenticationProvider": null,
    //             "userArn": null,
    //             "userAgent": "okhttp/3.12.0",
    //             "user": null
    //         },
    //         "domainName": "2ocwnhz66m.execute-api.ap-south-1.amazonaws.com",
    //         "apiId": "2ocwnhz66m"
    //     },
    //     "body": "{\"formattedAddress\":\"1, 1st Cross Rd, Prasanth Extension, Whitefield, Bengaluru, Karnataka 560066, India\\n\",\"adminArray\":[\"e33bc036-c686-44fe-9ffd-06746fbcb221\",\"6ae30d7f-75f0-4e2f-b2e7-8c8e89a680f4\",\"4022989b-2e81-46a5-8d43-c595e2ec7564\"],\"batteryState\":83,\"reason\":\"\",\"deviceType\":0,\"status\":1,\"driverId\":\"5ce38383eb581c337bdf215a\",\"driverName\":\"Hero \",\"imgUrl\":\"\",\"startLat\":12.9839293,\"startLng\":77.7500271,\"taskStatus\":10,\"_id\":\"5cef69845160c774ac882b2e\",\"topic\":\"task\",\"activeDist\":0.0}",
    //     "isBase64Encoded": false
    // }


    exports.handler = (event, context, callback) => {

    cb = callback;
    console.log('Event:' + JSON.stringify(event));
        context.callbackWaitsForEmptyEventLoop = false;

    getConstant.then(() => {
        //imports
        const db = require('./db').connect();
        const task = require('./updateTask');
        const helper = require('./util');


        const deviceToken = (event.deviceToken) ? event.deviceToken : helper.getDeviceToken(cb, event);
        const principals = (event.principals) ? event.principals : event.requestContext.authorizer.claims.sub;


        if (!principals) return;
        console.log('principals+++', principals);
        //connect to db
        // checking for normal body event or invoke lambda event
        // event.deviceToken exists if it is invoked from other lambda or else normal parse body data from event
        let bodyData = (event.deviceToken) ? event : helper.getBodyData(event);
        db.then(() => task.updateTask(bodyData , cb, principals, deviceToken)).catch(sendError);

        function sendError(error) {
            console.error('error +++', error);
            result.sendServerError(cb);
        }
    }).catch((err) => {
        console.log(err);
        result.sendServerError(cb);
    });
    };

} catch (err) {
    console.error('error +++', err);
    result.sendServerError(cb);
}







