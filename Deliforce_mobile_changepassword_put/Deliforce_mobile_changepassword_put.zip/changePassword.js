const result = require('./result');
const driverModel = require('./model');
const helper = require('./util');
const mongoose = require('./mongoose');
var empty = require('is-empty');

module.exports = {
    updatePassword:(event,cb,principals) => {
        const data = helper.getBodyData(event);
        if(!data){
            result.invalidInput(cb);
        } else {
            if(empty(data.newPassword) && empty(data.retypePassword) && empty(data.currentPassword)) {
                result.invalidPassword(cb);
            }
           // const clientId  =  principals['clientId'];
            const id = mongoose.Types.ObjectId(data['_id']);
            delete data['_id'];
            driverModel.update({clientId: clientId, _id: id}, data, {multi: false, runValidators: true}).then((data) => {
                result.sendSuccess(cb ,data);
            }).catch((error) => {handlerError(error,cb)});
        }
    }
};

function handlerError(error, cb) {
    const err = error.errors;
    if (err.password) {
        result.invalidPassword(cb);
    }
    else {
        result.sendServerError(cb);
    }
}






