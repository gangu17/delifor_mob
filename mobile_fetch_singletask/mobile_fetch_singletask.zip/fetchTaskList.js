const mongoose = require('mongoose');
const result = require('./result');
const helper = require('./util');
const constant = require('./constant')();
const isIt = constant.isIt;
const moment = require('moment-timezone');
const _ = require('lodash');
const taskModel = require('./model').task;
const userModel = require('./model').user;

module.exports = {
    fetchTasks: (event, cb, principals) => {
        console.log('fetch');
        const data = helper.getBodyData(event);
        if (!data) {
            result.invalidInput(cb);
            return;
        }
        const clientId = principals;
        console.log(clientId);
        if (!clientId) {
            result.sendUnAuth(cb);
            return;
        }
        userModel.findOne({cognitoSub: clientId}).then((driverDetails) =>{
            driverDetails = driverDetails.toObject();
            userModel.findOne({cognitoSub: driverDetails.clientId}).then((adminDetails) =>{
                adminDetails = adminDetails.toObject();

                taskModel.aggregate([{$match: {_id: mongoose.Types.ObjectId(data._id)}},
                    {
                        $lookup: {
                            from: "notes",
                            "let": { "taskId": "$_id" },
                            "pipeline": [
                                { "$match": {
                                        "$expr": {  $eq: [ "$$taskId",  "$taskId" ] },
                                        "isDeleted": 0
                                    }},
                            ],
                            as: "notes"
                        }
                    },
                    {
                        $lookup:{
                            from: "barcodes",
                            localField: "_id",
                            foreignField: "taskId",
                            as: "barcodes"
                        },
                    }


                ]).then((taskData) => {
                    console.log(taskData);
                    if (taskData.length) {
                        let t = taskData[0];
                        t.description = (t.description) ? t.description : '';
                        let stDate = new Date(t.date);
                        let tz = (adminDetails.timezone) ? adminDetails.timezone : 'Asia/Calcutta';
                        console.log('timezone', stDate);
                        let m = moment.utc(stDate, "YYYY-MM-DD h:mm:ss A");
                        t.date = m.tz(tz).format("YYYY-MM-DD h:mm:ss A");
                        if (t.businessType === 2 || t.businessType === 3) {
                            let endDate = t.endDate;
                            let m1 = moment.utc(endDate, "YYYY-MM-DD h:mm:ss A");
                            t.endDate = m1.tz(tz).format("YYYY-MM-DD h:mm:ss A");
                        }

                        console.log('new tasklist', JSON.stringify(t));

                        result.sendSuccess(cb, JSON.stringify({'taskData': t}));
                    } else {
                        result.sendSuccess(cb, {'status': 201, 'message': 'task not exist in the db'})
                    }

                }).catch((err) => {
                    console.log(err)
                })
            })
        });
    }


};

