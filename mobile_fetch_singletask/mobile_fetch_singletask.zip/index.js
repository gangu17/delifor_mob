let cb;
const result = require('./result');


try {
    const getConstant = require('./constant')();
    // const callback = function (err, data) {
    //     console.log('callback called+++++++++++++++++++++++++++++++++');
    //     console.log(err, data);
    // };
    // const event = require('../mock').admin.event;
    // event.queryStringParameters = require('../mock').admin.event.queryStringParameters;
    // console.log(event.queryStringParameters);

    exports.handler = (event, context, callback) => {

        console.log('Event:' + JSON.stringify(event));

        cb = callback;
        context.callbackWaitsForEmptyEventLoop = false;

        getConstant.then(() => {
            //imports
            const db = require('./db').connect();
            const task = require('./fetchTaskList');
            const helper = require('./util');

            if (helper.checkFromTrigger(cb, event)) return;

            /*
            principals explanation: for admin sub is clientId for manager clientId is clientId
            {  sub: 'current user cognitosub',
            role: 'role id of user',
            clientId:'exist if user is manager & this is clientid of that manager',
            teams: 'team Assigned to manager' }
            */

            const principals = event.requestContext.authorizer.claims.sub;
            //   const principals="3628e1a2-d041-4cd6-85e3-dfb40a882839";
            if (!principals) return;


            //connect to db
            db.then(() => task.fetchTasks(event, cb, principals)).catch(sendError);

            function sendError(error) {
                console.error('error +++', error);
                result.sendServerError(cb);
            }
        }).catch((err) => {
            console.log(err);
            result.sendServerError(cb);
        });
    };

} catch (err) {
    console.error('error +++', err);
    result.sendServerError(cb);
}







